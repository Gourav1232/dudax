
<script>
var typed=new Typed(".auto",{
    Strings:['designer','ui ux designer','quality analysis'],
    typespeed: 150,
    backspeed: 150,
    looped:true
})
</script>